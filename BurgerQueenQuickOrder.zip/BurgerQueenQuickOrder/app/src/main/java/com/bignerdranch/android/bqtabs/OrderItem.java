package com.bignerdranch.android.bqtabs;

public class OrderItem {

    private int itemid;

    public OrderItem(int itemid){
        this.itemid = itemid;
    }

    public int getItemid() {
        return itemid;
    }
}
